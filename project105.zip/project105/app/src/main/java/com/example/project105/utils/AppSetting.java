package com.example.project105.utils;

public final class AppSetting {

    public static final String PREFERENCES_NAME = "chordnote_pref";

    public static final String BASE_URL = "http://212.64.92.236:10000/api/v1/";

}
