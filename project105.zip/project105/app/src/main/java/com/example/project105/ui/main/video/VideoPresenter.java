package com.example.project105.ui.main.video;

import com.example.project105.ui.base.MvpPresenter;

public interface VideoPresenter<V extends VideoView> extends MvpPresenter<V> {

    void refresh();

}
