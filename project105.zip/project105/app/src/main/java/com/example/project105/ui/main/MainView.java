package com.example.project105.ui.main;

import com.example.project105.ui.base.MvpView;

public interface MainView extends MvpView {
}
