package com.example.project105.ui.main;

import com.example.project105.ui.base.MvpPresenter;

public interface MainPresenter<V extends MainView> extends MvpPresenter<V> {
}
