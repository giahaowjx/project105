package com.example.project105.ui.main.video;

import com.example.project105.ui.base.MvpView;

public interface VideoView extends MvpView {
}
