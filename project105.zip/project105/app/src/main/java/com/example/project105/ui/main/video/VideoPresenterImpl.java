package com.example.project105.ui.main.video;

import com.example.project105.data.DataManager;
import com.example.project105.ui.base.BasePresenter;

import javax.inject.Inject;

public class VideoPresenterImpl<V extends VideoView> extends BasePresenter<V> implements VideoPresenter<V> {

    @Inject
    public VideoPresenterImpl(DataManager manager) {
        super(manager);
    }

    @Override
    public void refresh() {
        return;
    }
}
