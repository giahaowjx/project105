package com.example.project105.ui.information;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.project105.R;

public class UserInforActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_infor);
    }
}
