package com.example.project105.ui.register;

import com.example.project105.ui.base.MvpView;

public interface RegisterView extends MvpView {

    void closeRegisterView();

}
