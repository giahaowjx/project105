package com.example.project105.ui.splash;

import com.example.project105.ui.base.MvpView;

public interface SplashView extends MvpView {

    void openMainActivity();

}
