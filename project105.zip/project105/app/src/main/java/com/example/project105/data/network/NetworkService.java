package com.example.project105.data.network;

import com.example.project105.data.network.model.CheckCodeResponse;
import com.example.project105.data.network.model.LoginResponse;
import com.example.project105.data.network.model.RegisterResponse;

import java.util.Map;

import okhttp3.RequestBody;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.PartMap;
import retrofit2.http.Query;
import rx.Observable;

public interface NetworkService {

    @GET("register/")
    Observable<CheckCodeResponse> getCheckCode(@Query("email") String email);

    @Multipart
    @POST("register/")
    Observable<RegisterResponse> postRegisterRequest(@PartMap Map<String, RequestBody> requestBodyMap);

    @Multipart
    @POST("auth/")
    Observable<LoginResponse> postLoginRequest(@PartMap Map<String, RequestBody> requestBodyMap);

}
