package com.example.project105.data.db;

public interface DbHelper {

}
