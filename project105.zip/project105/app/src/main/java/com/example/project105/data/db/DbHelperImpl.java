package com.example.project105.data.db;


//
//import com.example.project105.data.db.model.DaoMaster;
//import com.example.project105.data.db.model.DaoSession;

import javax.inject.Singleton;

@Singleton
public class DbHelperImpl implements DbHelper {

//    private DaoSession session;

    public DbHelperImpl(DbOpenHelper helper) {
//        SQLiteDatabase db = helper.getWritableDatabase();
//        DaoMaster daoMaster = new DaoMaster(db);
//        session = daoMaster.newSession();
    }


}
