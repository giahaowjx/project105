package com.example.project105.ui.login;

import com.example.project105.ui.base.MvpView;

public interface LoginView extends MvpView {

    void openRegisterActivity();
}
