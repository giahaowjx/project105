package com.example.project105.ui.splash;

import com.example.project105.ui.base.MvpPresenter;
import com.example.project105.ui.base.MvpView;

public interface SplashPresenter<V extends MvpView> extends MvpPresenter<V> {
}
